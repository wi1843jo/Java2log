package fifoqueue;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class FifoQueue<E> extends AbstractQueue<E> {

    // nod i kö, som inehåller sparade värdet
    private static class Node<E> {
        E element;
        Node<E> next;

        Node(E element) {
            this.element = element; //Ny nod med givet värde
            this.next = null;
        }
    }

    private Node<E> last; // Håller sista noden
    private int size; // Antal element i kön

    //Initiera tom kö
    public FifoQueue() {
        this.last = null;
        this.size = 0;
    }
    //Returnar element antal
    @Override
    public int size() {
        return size;
    }


    //Nytt element läggs till (e)
    @Override
    public boolean offer(E e) {
        if (e == null) {
            throw new NullPointerException("Null elements are not allowed");
        }

        Node<E> newNode = new Node<>(e);
        if (last == null) {
            // skapas cirkulär referns
            newNode.next = newNode;
            last = newNode;
        } else {
            // Sätts den in mellan första och sista
            newNode.next = last.next;
            last.next = newNode;
            last = newNode;
        }
        size++;
        return true;
    }

    //Ta bort och returnerar första elementet i kön
    @Override
    public E poll() {
        if (last == null) {
            return null; // Tom
        }

        Node<E> first = last.next;
        E element = first.element;

        if (last == first) {
            // Finns bara en
            last = null;
        } else {
            // Annars tas första bort
            last.next = first.next;
        }
        size--;
        return element;
    }

    //Returnerar första elementet (tas inte bort)
    @Override
    public E peek() {
        if (last == null) {
            return null; // tom queue
        }
        return last.next.element;
    }
 //Skapar och returnerar ny queueiterator
    @Override
    public Iterator<E> iterator() {
        return new QueueIterator();
    }

    // Slår ihop 2 fifoqueues
    public void concat(FifoQueue<E> other) {
        if (this == other) {
            throw new IllegalArgumentException("Cannot merge a queue with itself"); //Kollar så dom inte är samma
        }
        if (other.isEmpty()) {
            return; // om tom händer inget
        }
        if (this.isEmpty()) {
            // Om tom får den andra köns struktur
            this.last = other.last;
        } else {
            // uppdatera
            Node<E> thisFirst = this.last.next;
            Node<E> otherFirst = other.last.next;

            this.last.next = otherFirst; // Connect this queue's last to the other's first
            other.last.next = thisFirst; // Connect the other's last to this queue's first

            this.last = other.last; // Update this queue's last reference
        }
        this.size += other.size;
        other.last = null; // töm kön
        other.size = 0;
    }

    // Inner private class for the iterator
    private class QueueIterator implements Iterator<E> {
        private Node<E> current = (last == null) ? null : last.next; //håller koll på akutell nod
        private int count = 0; // räknar antalet element som har itererats

        //Returnerar true om fler element finns att iterera över.
        @Override
        public boolean hasNext() {
            return count < size;
        }

        //Returnerar det aktuella elementet och flyttar till nästa. Kastar NoSuchElementException om det inte finns fler element.
        @Override
        public E next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements");
            }
            E element = current.element;
            current = current.next;
            count++;
            return element;
        }
    }
}
