package fifoqueue;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FifoQueueAppendTest {


    //Två tomma köer sätts ihop
    @Test
    void testMergeTwoEmptyQueues() {
        FifoQueue<String> queue1 = new FifoQueue<>();
        FifoQueue<String> queue2 = new FifoQueue<>();
        queue1.concat(queue2);

        assertEquals(0, queue1.size(), "Merged queue should be empty");
        assertEquals(0, queue2.size(), "Second queue should remain empty");
    }

    //Tom med icke tom kö
    @Test
    void testMergeEmptyIntoNonEmptyQueue() {
        FifoQueue<String> queue1 = new FifoQueue<>();
        queue1.offer("A");
        FifoQueue<String> queue2 = new FifoQueue<>();
        queue1.concat(queue2);

        assertEquals(1, queue1.size(), "Merged queue size should remain unchanged");
        assertEquals("A", queue1.peek(), "Merged queue should retain original elements");
        assertEquals(0, queue2.size(), "Second queue should remain empty");
    }
    //Icke tom med tom
    @Test
    void testMergeNonEmptyIntoEmptyQueue() {
        FifoQueue<String> queue1 = new FifoQueue<>();
        FifoQueue<String> queue2 = new FifoQueue<>();
        queue2.offer("A");
        queue1.concat(queue2);

        assertEquals(1, queue1.size(), "Merged queue should contain the other queue's elements");
        assertEquals("A", queue1.peek(), "Merged queue should have the correct elements");
        assertEquals(0, queue2.size(), "Second queue should be empty after merging");
    }

    //Två köer som inte är tomma
    @Test
    void testMergeTwoNonEmptyQueues() {
        FifoQueue<String> queue1 = new FifoQueue<>();
        queue1.offer("A");
        queue1.offer("B");

        FifoQueue<String> queue2 = new FifoQueue<>();
        queue2.offer("C");
        queue2.offer("D");

        queue1.concat(queue2);

        assertEquals(4, queue1.size(), "Merged queue should contain all elements from both queues");
        assertEquals("A", queue1.poll());
        assertEquals("B", queue1.poll());
        assertEquals("C", queue1.poll());
        assertEquals("D", queue1.poll());
        assertEquals(0, queue2.size(), "Second queue should be empty after merging");
    }

    //Slå ihop med sig själv
    @Test
    void testMergeQueueWithItself() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");

        assertThrows(IllegalArgumentException.class, () -> queue.concat(queue), "Merging a queue with itself should throw an exception");
    }
}
