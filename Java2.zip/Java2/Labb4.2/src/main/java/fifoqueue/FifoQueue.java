package fifoqueue;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

public class FifoQueue<E> extends AbstractQueue<E> {

    // Inner Node class for the circular singly linked list
    private static class Node<E> {
        E element;
        Node<E> next;

        Node(E element) {
            this.element = element;
            this.next = null;
        }
    }

    private Node<E> last; // Reference to the last node
    private int size; // Size of the queue
    private final LinkedList<E> backupList = new LinkedList<>(); // For iterator purposes

    public FifoQueue() {
        this.last = null; // Empty list
        this.size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean offer(E e) {
        if (e == null) {
            throw new NullPointerException("Null elements are not allowed");
        }

        Node<E> newNode = new Node<>(e);
        if (last == null) {
            // First element, circular reference to itself
            newNode.next = newNode;
            last = newNode;
        } else {
            // Insert between last and first
            newNode.next = last.next;
            last.next = newNode;
            last = newNode;
        }
        size++;
        backupList.add(e); // Sync with the LinkedList
        return true;
    }

    @Override
    public E poll() {
        if (last == null) {
            return null; // Empty queue
        }

        Node<E> first = last.next;
        E element = first.element;

        if (last == first) {
            // Only one node
            last = null;
        } else {
            // Remove the first node
            last.next = first.next;
        }
        size--;
        backupList.poll(); // Sync with the LinkedList
        return element;
    }

    @Override
    public E peek() {
        if (last == null) {
            return null; // Empty queue
        }
        return last.next.element; // First element
    }

    @Override
    public Iterator<E> iterator() {
        return backupList.iterator(); // Use LinkedList for iterator
    }
}
