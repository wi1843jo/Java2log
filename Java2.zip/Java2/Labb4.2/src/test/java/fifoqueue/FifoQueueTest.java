package fifoqueue;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FifoQueueTest {

    @Test
    void testEmptyQueue() {
        FifoQueue<String> queue = new FifoQueue<>();
        assertEquals(0, queue.size());
        assertNull(queue.peek());
        assertNull(queue.poll());
    }

    @Test
    void testOfferIncreasesSize() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        assertEquals(1, queue.size());
        queue.offer("B");
        assertEquals(2, queue.size());
    }

    @Test
    void testPeek() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        assertEquals("A", queue.peek());
        assertEquals(2, queue.size());
    }

    @Test
    void testPoll() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        assertEquals("A", queue.poll());
        assertEquals(1, queue.size());
        assertEquals("B", queue.poll());
        assertEquals(0, queue.size());
    }

    @Test
    void testCircularBehavior() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        queue.poll();
        queue.offer("C");
        assertEquals("B", queue.poll());
        assertEquals("C", queue.poll());
    }

    @Test
    void testEmptyingQueue() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        queue.poll();
        queue.poll();
        assertNull(queue.poll());
        assertEquals(0, queue.size());
    }
}
