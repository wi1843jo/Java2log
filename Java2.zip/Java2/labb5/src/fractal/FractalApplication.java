package fractal;

import koch.Koch;
import mountain.Mountain;
import mountain.Point;

public class FractalApplication {
	public static void main(String[] args) {
		Fractal[] fractals = new Fractal[2];

		// Lägg till Mountain-fraktalen
		Point p1 = new Point(125, 400);
		Point p2 = new Point(475, 400);
		Point p3 = new Point(300, 100);
		fractals[0] = new Mountain(p1, p2, p3, 50);

		// Lägg till Koch-fraktalen
		fractals[1] = new Koch(300);

		new FractalView(fractals, "Fraktaler", 600, 600);
	}

}
