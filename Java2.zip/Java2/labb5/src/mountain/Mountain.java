package mountain;

import fractal.*;
import java.util.HashMap;

public class Mountain extends Fractal {
    private Point p1, p2, p3;
    private double initialDev;
    private HashMap<Side, Point> sideMap;

    /**
     * Creates a Mountain fractal object.
     * @param p1 the first point of the initial triangle
     * @param p2 the second point of the initial triangle
     * @param p3 the third point of the initial triangle
     * @param initialDev the starting deviation for randomness
     */
    public Mountain(Point p1, Point p2, Point p3, double initialDev) {
        super();
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.initialDev = initialDev;
        this.sideMap = new HashMap<>();
    }

    @Override
    public String getTitle() {
        return "Bergfraktal";
    }

    @Override
    public void draw(TurtleGraphics turtle) {
        drawTriangle(turtle, order, p1, p2, p3, initialDev);
    }

    /**
     * Recursive method to draw the mountain fractal with shared sides.
     * @param turtle the TurtleGraphics object
     * @param order the current recursion depth
     * @param p1 the first point of the triangle
     * @param p2 the second point of the triangle
     * @param p3 the third point of the triangle
     * @param dev the current deviation for randomness
     */
    private void drawTriangle(TurtleGraphics turtle, int order, Point p1, Point p2, Point p3, double dev) {
        if (order == 0) {
            // Base case: Draw the triangle
            turtle.moveTo(p1.getX(), p1.getY());
            turtle.forwardTo(p2.getX(), p2.getY());
            turtle.forwardTo(p3.getX(), p3.getY());
            turtle.forwardTo(p1.getX(), p1.getY());
        } else {
            // Recursive case: Calculate midpoints with shared sides
            Point mid1 = getMidpoint(new Side(p1, p2), dev);
            Point mid2 = getMidpoint(new Side(p2, p3), dev);
            Point mid3 = getMidpoint(new Side(p3, p1), dev);

            // Halve the deviation for the next recursion level
            double nextDev = dev / 2.0;

            // Recursively draw the four smaller triangles
            drawTriangle(turtle, order - 1, p1, mid1, mid3, nextDev);
            drawTriangle(turtle, order - 1, mid1, p2, mid2, nextDev);
            drawTriangle(turtle, order - 1, mid3, mid2, p3, nextDev);
            drawTriangle(turtle, order - 1, mid1, mid2, mid3, nextDev);
        }
    }

    /**
     * Retrieves or calculates the midpoint of a Side.
     * If the Side exists in the map, its midpoint is reused. Otherwise, a new midpoint
     * is calculated, stored in the map, and returned.
     * @param side the Side for which to find or calculate the midpoint
     * @param dev the current deviation for randomness
     * @return the midpoint of the Side
     */
    private Point getMidpoint(Side side, double dev) {
        if (sideMap.containsKey(side)) {
            // Reuse the existing midpoint
            return sideMap.remove(side);
        } else {
            // Calculate a new midpoint with random offset
            Point p1 = side.getP1();
            Point p2 = side.getP2();
            int midX = (p1.getX() + p2.getX()) / 2;
            int midY = (p1.getY() + p2.getY()) / 2;
            double offset = RandomUtilities.randFunc(dev);
            Point midpoint = new Point(midX, (int) (midY + offset));

            // Store the midpoint in the map
            sideMap.put(side, midpoint);
            return midpoint;
        }
    }
}
