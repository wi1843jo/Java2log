package mountain;

import java.util.Objects;

public class Side {
    private Point p1, p2;

    /**
     * Constructs a Side with two endpoints.
     * @param p1 the first endpoint
     * @param p2 the second endpoint
     */
    public Side(Point p1, Point p2) {
        // Ensures consistent ordering of points for equality checks
        if (p1.hashCode() <= p2.hashCode()) {
            this.p1 = p1;
            this.p2 = p2;
        } else {
            this.p1 = p2;
            this.p2 = p1;
        }
    }

    @Override
    public int hashCode() {
        return p1.hashCode() + p2.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Side)) return false;
        Side other = (Side) obj;
        return (Objects.equals(p1, other.p1) && Objects.equals(p2, other.p2)) ||
                (Objects.equals(p1, other.p2) && Objects.equals(p2, other.p1));
    }

    @Override
    public String toString() {
        return "Side{" + p1 + ", " + p2 + "}";
    }
}
