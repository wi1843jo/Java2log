package mountain;

import fractal.*;
import fractal.TurtleGraphics;

public class Mountain extends Fractal {
    private Point p1, p2, p3;
    private double initialDev; // Initial deviation

    /**
     * Creates a Mountain fractal object.
     * @param p1 the first point of the initial triangle
     * @param p2 the second point of the initial triangle
     * @param p3 the third point of the initial triangle
     * @param initialDev the starting deviation for randomness
     */
    public Mountain(Point p1, Point p2, Point p3, double initialDev) {
        super();
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.initialDev = initialDev;
    }

    @Override
    public String getTitle() {
        return "Mountain Fractal with Randomness";
    }

    @Override
    public void draw(TurtleGraphics turtle) {
        drawTriangle(turtle, order, p1, p2, p3, initialDev);
    }

    /**
     * Recursive method to draw the mountain fractal with randomness.
     * @param turtle the TurtleGraphics object
     * @param order the current recursion depth
     * @param p1 the first point of the triangle
     * @param p2 the second point of the triangle
     * @param p3 the third point of the triangle
     * @param dev the current deviation for randomness
     */
    private void drawTriangle(TurtleGraphics turtle, int order, Point p1, Point p2, Point p3, double dev) {
        if (order == 0) {
            // Base case: Draw the triangle
            turtle.moveTo(p1.getX(), p1.getY());
            turtle.forwardTo(p2.getX(), p2.getY());
            turtle.forwardTo(p3.getX(), p3.getY());
            turtle.forwardTo(p1.getX(), p1.getY());
        } else {
            // Recursive case: Calculate midpoints with randomness
            Point mid1 = midpointWithOffset(p1, p2, dev);
            Point mid2 = midpointWithOffset(p2, p3, dev);
            Point mid3 = midpointWithOffset(p3, p1, dev);

            // Halve the deviation for the next recursion level
            double nextDev = dev / 2.0;

            // Recursively draw the four smaller triangles
            drawTriangle(turtle, order - 1, p1, mid1, mid3, nextDev);
            drawTriangle(turtle, order - 1, mid1, p2, mid2, nextDev);
            drawTriangle(turtle, order - 1, mid3, mid2, p3, nextDev);
            drawTriangle(turtle, order - 1, mid1, mid2, mid3, nextDev);
        }
    }

    /**
     * Calculates the midpoint between two points with a random y-offset.
     * @param p1 the first point
     * @param p2 the second point
     * @param dev the current deviation for randomness
     * @return a new Point that is the midpoint with a random y-offset
     */
    private Point midpointWithOffset(Point p1, Point p2, double dev) {
        int midX = (p1.getX() + p2.getX()) / 2;
        int midY = (p1.getY() + p2.getY()) / 2;

        // Add random deviation to the y-coordinate
        double offset = RandomUtilities.randFunc(dev);
        return new Point(midX, (int) (midY + offset));
    }
}
