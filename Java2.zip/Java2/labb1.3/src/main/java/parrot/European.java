package parrot;

public record European() implements Parrot{
    @Override
    public String parrotLives() {
        return "bor i ett bo byggt av pinnar";
    }

    @Override
    public double getSpeed() {
        return getBaseSpeed();
    }

    private double getBaseSpeed() {
        return 12.0;
    }
}