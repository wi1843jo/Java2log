package parrot;

public interface Parrot {
    String parrotLives();
    double getSpeed();
}