package parrot;

    public record NorwegianBlue(double voltage, boolean isNailed) implements Parrot{

    @Override
    public String parrotLives() {
        return isNailed ? "bor i en bur" : "ingenstans";
    }

    @Override
    public double getSpeed() {
        return isNailed ? 0 : getBaseSpeed(voltage);
    }


    private double getBaseSpeed(double voltage) {
        return Math.min(24.0, voltage * getBaseSpeed());
    }

    private double getBaseSpeed() {
        return 12.0;
    }
}

