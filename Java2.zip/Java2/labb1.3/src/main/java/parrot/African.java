package parrot;

public record African(int numberOfCoconuts) implements Parrot {
    @Override
    public String parrotLives() {
        return "bor i hål i träd";
    }

    @Override
    public double getSpeed() {
        return Math.max(0, getBaseSpeed() - getLoadFactor() * numberOfCoconuts);
    }


    private double getBaseSpeed() {
        return 12.0;
    }

    private double getLoadFactor() {
        return 9.0;
    }
}

