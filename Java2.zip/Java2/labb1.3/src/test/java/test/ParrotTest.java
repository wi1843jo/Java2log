package test;

import org.junit.jupiter.api.Test;
import parrot.Parrot;
import parrot.ParrotFactory;
import parrot.ParrotTypeEnum;

import static org.junit.jupiter.api.Assertions.*;
public class ParrotTest {

    private static Parrot getParrot(ParrotTypeEnum type, int numberOfCoconuts, double voltage, boolean isNailed) {
        return ParrotFactory.getParrot(type, numberOfCoconuts, voltage, isNailed);
    }

    @Test public void getLivesEuropeanParrot() {
        Parrot parrot = getParrot(ParrotTypeEnum.EUROPEAN, 0, 0, false);
        assertEquals("bor i ett bo byggt av pinnar", parrot.parrotLives());
    }
    @Test public void getLivesAfricanParrot() {
        Parrot parrot = getParrot(ParrotTypeEnum.AFRICAN, 0, 0, false);
        assertEquals("bor i hål i träd", parrot.parrotLives());
    }
    @Test public void getLivesNorwegianParrotIsNailed() {
        Parrot parrot = getParrot(ParrotTypeEnum.NORWEGIAN_BLUE, 0, 0, true);
        assertEquals("bor i en bur", parrot.parrotLives());
    }
    @Test public void getLivesNorwegianParrotNotNailed() {
        Parrot parrot = getParrot(ParrotTypeEnum.NORWEGIAN_BLUE, 0, 0, false);
        assertEquals("ingenstans", parrot.parrotLives());
    }
        @Test
    public void getSpeedOfEuropeanParrot() {
        Parrot parrot = getParrot(ParrotTypeEnum.EUROPEAN, 0, 0, false);
        assertEquals(12.0, parrot.getSpeed(), 0.0);
    }

    @Test
    public void getSpeedOfAfricanParrot_With_One_Coconut() {
        Parrot parrot = getParrot(ParrotTypeEnum.AFRICAN, 1, 0, false);
        assertEquals(3.0, parrot.getSpeed(), 0.0);
    }

    @Test
    public void getSpeedOfAfricanParrot_With_Two_Coconuts() {
        Parrot parrot = getParrot(ParrotTypeEnum.AFRICAN, 2, 0, false);
        assertEquals(0.0, parrot.getSpeed(), 0.0);
    }

    @Test
    public void getSpeedOfAfricanParrot_With_No_Coconuts() {
        Parrot parrot = getParrot(ParrotTypeEnum.AFRICAN, 0, 0, false);
        assertEquals(12.0, parrot.getSpeed(), 0.0);
    }

    @Test
    public void getSpeedNorwegianBlueParrot_nailed() {
        Parrot parrot = getParrot(ParrotTypeEnum.NORWEGIAN_BLUE, 0, 1.5, true);
        assertEquals(0.0, parrot.getSpeed(), 0.0);
    }

    @Test
    public void getSpeedNorwegianBlueParrot_not_nailed() {
        Parrot parrot = getParrot(ParrotTypeEnum.NORWEGIAN_BLUE, 0, 1.5, false);
        assertEquals(18.0, parrot.getSpeed(), 0.0);
    }

    @Test
    public void getSpeedNorwegianBlueParrot_not_nailed_high_voltage() {
        Parrot parrot = getParrot(ParrotTypeEnum.NORWEGIAN_BLUE, 0, 4, false);
        assertEquals(24.0, parrot.getSpeed(), 0.0);
    }
}
