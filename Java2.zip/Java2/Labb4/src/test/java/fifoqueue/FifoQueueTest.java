package fifoqueue;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FifoQueueTest {

    @Test
    void testEmptyQueue() {
        FifoQueue<String> queue = new FifoQueue<>();
        assertEquals(0, queue.size(), "Size of an empty queue should be 0");
        assertNull(queue.peek(), "Peek on an empty queue should return null");
        assertNull(queue.poll(), "Poll on an empty queue should return null");
    }

    @Test
    void testOfferIncreasesSize() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        assertEquals(1, queue.size(), "Size should increase after offering an element");
        queue.offer("B");
        assertEquals(2, queue.size(), "Size should reflect the number of elements in the queue");
    }

    @Test
    void testPeek() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        assertEquals("A", queue.peek(), "Peek should return the first element");
        assertEquals(2, queue.size(), "Size should not change after peeking");
    }

    @Test
    void testPoll() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        assertEquals("A", queue.poll(), "Poll should return the first element");
        assertEquals(1, queue.size(), "Size should decrease after polling");
        assertEquals("B", queue.poll(), "Poll should return the next element in FIFO order");
        assertEquals(0, queue.size(), "Queue should be empty after polling all elements");
    }

    @Test
    void testCircularBehavior() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        queue.poll(); // Remove "A"
        queue.offer("C"); // Add "C"
        assertEquals("B", queue.poll(), "Poll should return the next element in FIFO order");
        assertEquals("C", queue.poll(), "Poll should handle circular behavior correctly");
        assertNull(queue.poll(), "Queue should be empty after polling all elements");
    }

    @Test
    void testQueueCanBeEmptiedCompletely() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        queue.poll(); // Remove "A"
        queue.poll(); // Remove "B"
        assertNull(queue.poll(), "Polling an empty queue should return null");
        assertEquals(0, queue.size(), "Size should be 0 after emptying the queue");
    }

    @Test
    void testAddingAndRemovingMultipleElements() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        queue.offer("C");
        String result = queue.poll() + queue.poll() + queue.poll();
        assertEquals("ABC", result, "Elements should be polled in FIFO order");
    }
}
