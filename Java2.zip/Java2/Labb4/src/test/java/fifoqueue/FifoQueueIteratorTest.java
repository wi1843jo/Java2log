package fifoqueue;

import org.junit.jupiter.api.Test;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class FifoQueueIteratorTest {

    @Test
    void hasNextReturnsFalseOnEmptyList() {
        FifoQueue<String> queue = new FifoQueue<>();
        Iterator<String> iterator = queue.iterator();
        assertFalse(iterator.hasNext());
    }

    @Test
    void hasNextReturnsTrueOnNonEmptyList() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        Iterator<String> iterator = queue.iterator();
        assertTrue(iterator.hasNext());
    }

    @Test
    void nextThrowsExceptionOnEmptyList() {
        FifoQueue<String> queue = new FifoQueue<>();
        Iterator<String> iterator = queue.iterator();
        assertThrows(NoSuchElementException.class, iterator::next);
    }

    @Test
    void nextReturnsElementIfExists() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        Iterator<String> iterator = queue.iterator();
        assertEquals("A", iterator.next());
    }

    @Test
    void nextDoesNotModifyQueue() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        Iterator<String> iterator = queue.iterator();
        iterator.next();
        assertEquals(1, queue.size());
        assertEquals("A", queue.peek());
    }

    @Test
    void multipleIteratorsWorkIndependently() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("A");
        queue.offer("B");
        Iterator<String> iterator1 = queue.iterator();
        Iterator<String> iterator2 = queue.iterator();

        assertEquals("A", iterator1.next());
        assertEquals("A", iterator2.next());
        assertEquals("B", iterator1.next());
        assertEquals("B", iterator2.next());
    }
}
