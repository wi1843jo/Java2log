package fifoqueue;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class FifoQueue<E> extends AbstractQueue<E> {

    // Inner Node class for the circular singly linked list
    private static class Node<E> {
        E element;
        Node<E> next;

        Node(E element) {
            this.element = element;
            this.next = null;
        }
    }

    private Node<E> last; // Reference to the last node
    private int size; // Size of the queue

    public FifoQueue() {
        this.last = null; // Empty list
        this.size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean offer(E e) {
        if (e == null) {
            throw new NullPointerException("Null elements are not allowed");
        }

        Node<E> newNode = new Node<>(e);
        if (last == null) {
            // First element, circular reference to itself
            newNode.next = newNode;
            last = newNode;
        } else {
            // Insert between last and first
            newNode.next = last.next;
            last.next = newNode;
            last = newNode;
        }
        size++;
        return true;
    }

    @Override
    public E poll() {
        if (last == null) {
            return null; // Empty queue
        }

        Node<E> first = last.next;
        E element = first.element;

        if (last == first) {
            // Only one node
            last = null;
        } else {
            // Remove the first node
            last.next = first.next;
        }
        size--;
        return element;
    }

    @Override
    public E peek() {
        if (last == null) {
            return null; // Empty queue
        }
        return last.next.element; // First element
    }

    @Override
    public Iterator<E> iterator() {
        return new QueueIterator();
    }

    // Merge another FifoQueue into this one
    public void concat(FifoQueue<E> other) {
        if (this == other) {
            throw new IllegalArgumentException("Cannot merge a queue with itself");
        }
        if (other.isEmpty()) {
            return; // Nothing to merge if the other queue is empty
        }
        if (this.isEmpty()) {
            // If this queue is empty, simply adopt the other queue's structure
            this.last = other.last;
        } else {
            // Merge the circular linked lists
            Node<E> thisFirst = this.last.next;
            Node<E> otherFirst = other.last.next;

            this.last.next = otherFirst; // Connect this queue's last to the other's first
            other.last.next = thisFirst; // Connect the other's last to this queue's first

            this.last = other.last; // Update this queue's last reference
        }
        this.size += other.size;
        other.last = null; // Clear the other queue
        other.size = 0;
    }

    // Inner private class for the iterator
    private class QueueIterator implements Iterator<E> {
        private Node<E> current = (last == null) ? null : last.next;
        private int count = 0; // To track the number of elements iterated

        @Override
        public boolean hasNext() {
            return count < size;
        }

        @Override
        public E next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements");
            }
            E element = current.element;
            current = current.next;
            count++;
            return element;
        }
    }
}
