package mountain;

import fractal.*;
import fractal.TurtleGraphics;

public class Mountain extends Fractal {
    private Point p1, p2, p3;

    /**
     * Creates a Mountain fractal object.
     * @param p1 the first point of the initial triangle
     * @param p2 the second point of the initial triangle
     * @param p3 the third point of the initial triangle
     */
    public Mountain(Point p1, Point p2, Point p3) {
        super();
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    @Override
    public String getTitle() {
        return "Mountain Fractal";
    }

    @Override
    public void draw(TurtleGraphics turtle) {
        drawTriangle(turtle, order, p1, p2, p3);
    }

    /**
     * Recursive method to draw the mountain fractal.
     * @param turtle the TurtleGraphics object
     * @param order the current recursion depth
     * @param p1 the first point of the triangle
     * @param p2 the second point of the triangle
     * @param p3 the third point of the triangle
     */
    private void drawTriangle(TurtleGraphics turtle, int order, Point p1, Point p2, Point p3) {
        if (order == 0) {
            // Base case: Draw the triangle
            turtle.moveTo(p1.getX(), p1.getY());
            turtle.forwardTo(p2.getX(), p2.getY());
            turtle.forwardTo(p3.getX(), p3.getY());
            turtle.forwardTo(p1.getX(), p1.getY());
        } else {
            // Recursive case: Divide the triangle into 4 smaller triangles
            Point mid1 = midpoint(p1, p2);
            Point mid2 = midpoint(p2, p3);
            Point mid3 = midpoint(p3, p1);

            // Draw four smaller triangles
            drawTriangle(turtle, order - 1, p1, mid1, mid3);
            drawTriangle(turtle, order - 1, mid1, p2, mid2);
            drawTriangle(turtle, order - 1, mid3, mid2, p3);
            drawTriangle(turtle, order - 1, mid1, mid2, mid3);
        }
    }

    /**
     * Calculates the midpoint between two points.
     * @param p1 the first point
     * @param p2 the second point
     * @return the midpoint between p1 and p2
     */
    private Point midpoint(Point p1, Point p2) {
        int midX = (p1.getX() + p2.getX()) / 2;
        int midY = (p1.getY() + p2.getY()) / 2;
        return new Point(midX, midY);
    }
}
