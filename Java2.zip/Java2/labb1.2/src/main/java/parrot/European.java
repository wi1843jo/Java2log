package parrot;

public class European extends Parrot{
    public European(){
        super(0, 0, false);
    }
    @Override
    public String parrotLives() {
        return "bor i ett bo byggt av pinnar";
    }
    @Override
    public double getSpeed() {
        return getBaseSpeed();
    }
}
