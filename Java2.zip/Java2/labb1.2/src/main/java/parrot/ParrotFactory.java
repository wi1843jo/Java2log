package parrot;

public class ParrotFactory {
    public static Parrot getParrot(ParrotTypeEnum type, int numberOfCoconuts, double voltage, boolean isNailed) {
        return switch (type) {
            case EUROPEAN -> new European();
            case AFRICAN -> new African(numberOfCoconuts);
            case NORWEGIAN_BLUE -> new NorwegianBlue(voltage, isNailed);
            default -> throw new IllegalArgumentException("Invalid Parrot Type");
        };
    }
}

