package parrot;

public abstract class Parrot {

 //   private ParrotTypeEnum type;
    protected int numberOfCoconuts;
    protected double voltage;
    protected boolean isNailed;

    public Parrot(int numberOfCoconuts, double voltage, boolean isNailed) {
      //  this.type = type;
        this.numberOfCoconuts = numberOfCoconuts;
        this.voltage = voltage;
        this.isNailed = isNailed;
    }

    public abstract String parrotLives();
    public abstract double getSpeed();

 /*   public String parrotLives(){
        return switch (type) {
            case EUROPEAN -> "bor i ett bo byggt av pinnar";
            case AFRICAN -> "bor i hål i träd";
            case NORWEGIAN_BLUE ->  isNailed ? "bor i en bur" : "ingenstans";
            default -> throw new RuntimeException("Should be unreachable");
        };
    } */

 /*   public double getSpeed() {
        return switch (type) {
            case EUROPEAN -> getBaseSpeed();
            case AFRICAN -> Math.max(0, getBaseSpeed() - getLoadFactor() * numberOfCoconuts);
            case NORWEGIAN_BLUE -> (isNailed) ? 0 : getBaseSpeed(voltage);
            default -> throw new RuntimeException("Should be unreachable");
        };
    } */

    protected double getBaseSpeed(double voltage) {
        return Math.min(24.0, voltage * getBaseSpeed());
    }

    protected double getLoadFactor() {
        return 9.0;
    }

    protected double getBaseSpeed() {
        return 12.0;
    }

}
