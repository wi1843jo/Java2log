package parrot;

public class African extends Parrot {
    public African(int numberOfCoconuts) {
        super(numberOfCoconuts, 0, false);
    }

    @Override
    public String parrotLives() {
        return "bor i hål i träd";
    }

    @Override
    public double getSpeed() {
        return Math.max(0, getBaseSpeed() - getLoadFactor() * numberOfCoconuts);
    }
}

