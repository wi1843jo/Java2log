package parrot;

public class NorwegianBlue extends Parrot {
    public NorwegianBlue(double voltage, boolean isNailed) {
        super(0, voltage, isNailed);
    }

    @Override
    public String parrotLives() {
        return isNailed ? "bor i en bur" : "ingenstans";
    }

    @Override
    public double getSpeed() {
        return isNailed ? 0 : getBaseSpeed(voltage);
    }
}

