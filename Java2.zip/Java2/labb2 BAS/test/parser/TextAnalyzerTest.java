package parser;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.util.Scanner;


import static org.junit.jupiter.api.Assertions.assertEquals;

class TextAnalyzerTest {

    @Test
    @DisplayName("Can find Nils in nils.txt ")
    void analyzeText() throws FileNotFoundException {
        Scanner scanner = ScannerFactory.scannerForNaturalLanguage("test_data/nils.txt");
        TextProcessor textProcessor = new SingleWordCounter("nils");
        TextAnalyzer analyzer = new TextAnalyzer(textProcessor);
        assertEquals("nils: 2", analyzer.analyzeText(scanner));
    }

    @Test
    @DisplayName("Can find two nils and three norway in nils_norway.txt")
    void analyzeText2() throws FileNotFoundException {
        Scanner scannerNils = ScannerFactory.scannerForNaturalLanguage("test_data/nils_norway.txt");
        Scanner scannerNorway = ScannerFactory.scannerForNaturalLanguage("test_data/nils_norway.txt");


        TextProcessor nilsProcessor = new SingleWordCounter("nils");
        TextAnalyzer analyzerNils = new TextAnalyzer(nilsProcessor);
        String nilsResult = analyzerNils.analyzeText(scannerNils);

        TextProcessor norwayProcessor = new SingleWordCounter("norge");
        TextAnalyzer analyzerNorway = new TextAnalyzer(norwayProcessor);
        String norwayResult = analyzerNorway.analyzeText(scannerNorway);

        assertEquals("nils: 3", nilsResult);
        assertEquals("norge: 2", norwayResult);
    }
}