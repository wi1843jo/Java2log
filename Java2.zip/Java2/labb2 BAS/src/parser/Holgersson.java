package parser;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Holgersson {

	public static final String[] REGIONS = { "blekinge", "bohuslän", "dalarna", "dalsland", "gotland", "gästrikland",
			"halland", "hälsingland", "härjedalen", "jämtland", "lappland", "medelpad", "närke", "skåne", "småland",
			"södermanland", "uppland", "värmland", "västerbotten", "västergötland", "västmanland", "ångermanland",
			"öland", "östergötland" };

	public static void main(String[] args) throws FileNotFoundException {
		String pathname = "input/nilsholg.txt";
		Scanner scannerNils = ScannerFactory.scannerForNaturalLanguage(pathname);
		Scanner scannerNorway = ScannerFactory.scannerForNaturalLanguage("input/nilsholg.txt");

		TextProcessor nilsProcessor = new SingleWordCounter("nils");
		TextAnalyzer analyzerNils = new TextAnalyzer(nilsProcessor);
		String nilsResult = analyzerNils.analyzeText(scannerNils);

		TextProcessor norwayProcessor = new SingleWordCounter("norge");
		TextAnalyzer analyzerNorway = new TextAnalyzer(norwayProcessor);
		String norwayResult = analyzerNorway.analyzeText(scannerNorway);

		System.out.println(nilsResult);
		System.out.println(norwayResult);
	}

}