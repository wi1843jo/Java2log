package bst;

import java.util.ArrayList;
import java.util.Comparator;

public class BinarySearchTree<E> {
	private BinaryNode<E> root; // Roten i trädet
	private int size = 0; // Antal element i trädet
	private final Comparator<E> comparator; // Komparator för att jämföra element

	// * Konstruktor för ett tomt träd
	public BinarySearchTree() {
		this.comparator = null; // Naturlig ordning används om ingen komparator ges
	}

	// * Konstruktor för ett träd med en specifik komparator
	public BinarySearchTree(Comparator<E> comparator) {
		this.comparator = comparator;
	}

	// * Returnerar roten på trädet
	public BinaryNode<E> getRoot() {
		return this.root;
	}

	// * Lägger till ett element i trädet om det inte redan finns
	public boolean add(E e) {
		if (e == null) throw new IllegalArgumentException("Null values are not allowed"); // Null-värden tillåts inte
		if (root == null) { // Om trädet är tomt
			root = new BinaryNode<>(e);
			size++;
			return true;
		}
		return addRecursive(root, e); // Använd en rekursiv metod för att lägga till elementet
	}

	private boolean addRecursive(BinaryNode<E> node, E e) {
		int comparison = compare(e, node.element); // Jämför med nuvarande nod
		if (comparison == 0) return false; // Duplicat hittades
		if (comparison < 0) { // Lägg till i vänster subträd
			if (node.left == null) {
				node.left = new BinaryNode<>(e);
				size++;
				return true;
			} else {
				return addRecursive(node.left, e);
			}
		} else { // Lägg till i höger subträd
			if (node.right == null) {
				node.right = new BinaryNode<>(e);
				size++;
				return true;
			} else {
				return addRecursive(node.right, e);
			}
		}
	}

	// * Beräknar trädets höjd
	public int height() {
		return computeHeight(root); // Rekursiv beräkning av höjd
	}

	private int computeHeight(BinaryNode<E> node) {
		if (node == null) return -1; // Höjd för tomt träd är -1
		return 1 + Math.max(computeHeight(node.left), computeHeight(node.right)); // Rekursiv höjdberäkning
	}

	// * Returnerar antal element i trädet
	public int size() {
		return this.size;
	}

	// * Tar bort alla element från trädet
	public void clear() {
		root = null; // Nollställ roten
		size = 0; // Nollställ storleken
	}

	// * Bygger om trädet till ett balanserat träd
	public void rebuild() {
		ArrayList<E> sortedElements = toArray(); // Få elementen i sorterad ordning
		root = buildTree(sortedElements, 0, sortedElements.size() - 1); // Bygg ett balanserat träd
	}

	private BinaryNode<E> buildTree(ArrayList<E> sorted, int first, int last) {
		if (first > last) return null; // Basfall: tom subträd
		int mid = (first + last) / 2;
		BinaryNode<E> node = new BinaryNode<>(sorted.get(mid)); // Skapa nod från mitten
		node.left = buildTree(sorted, first, mid - 1); // Bygg vänster subträd
		node.right = buildTree(sorted, mid + 1, last); // Bygg höger subträd
		return node;
	}

	// * Returnerar en sorterad lista med trädets element
	public ArrayList<E> toArray() {
		ArrayList<E> sorted = new ArrayList<>();
		toArrayRecursive(root, sorted); // Rekursiv inorder-traversering
		return sorted;
	}

	private void toArrayRecursive(BinaryNode<E> node, ArrayList<E> sorted) {
		if (node == null) return; // Basfall: tom nod
		toArrayRecursive(node.left, sorted); // Traversera vänster subträd
		sorted.add(node.element); // Lägg till nuvarande element
		toArrayRecursive(node.right, sorted); // Traversera höger subträd
	}

	// * Returnerar en lista med element i pre-ordning
	public ArrayList<E> preOrdered() {
		ArrayList<E> preOrderedList = new ArrayList<>();
		preOrderRecursive(root, preOrderedList); // Rekursiv pre-ordningstraversering
		return preOrderedList;
	}

	private void preOrderRecursive(BinaryNode<E> node, ArrayList<E> list) {
		if (node == null) return; // Basfall: tom nod
		list.add(node.element); // Lägg till nuvarande element
		preOrderRecursive(node.left, list); // Traversera vänster subträd
		preOrderRecursive(node.right, list); // Traversera höger subträd
	}

	// Hjälpmetod för jämförelser
	@SuppressWarnings("unchecked")
	private int compare(E e1, E e2) {
		if (comparator != null) return comparator.compare(e1, e2); // Använd komparatorn om den finns
		return ((Comparable<E>) e1).compareTo(e2); // Annars använd naturlig ordning
	}

	// * Definierar en nod i trädet
	static class BinaryNode<E> implements Node<E> {
		E element; // Elementet i noden
		BinaryNode<E> left; // Vänster barn
		BinaryNode<E> right; // Höger barn

		private BinaryNode(E element) {
			this.element = element;
		}

		@Override
		public E getValue() {
			return this.element;
		}

		@Override
		public Node<E> getLeft() {
			return this.left;
		}

		@Override
		public Node<E> getRight() {
			return this.right;
		}



	}
	//lägger till för att få allt att funka
	@Override
	public String toString() {
		if (root == null) return ""; // Tomt träd representeras av en tom sträng
		StringBuilder result = new StringBuilder();
		buildString(root, result); // Bygger strängen rekursivt
		return result.substring(0, result.length() - 1); // Ta bort sista bindestrecket
	}

	private void buildString(BinaryNode<E> node, StringBuilder result) {
		if (node == null) return;
		buildString(node.left, result); // Traversera vänster subträd
		result.append(node.element).append("-"); // Lägg till elementet
		buildString(node.right, result); // Traversera höger subträd
	}

}