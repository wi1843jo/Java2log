package fifoqueue;
import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.LinkedList;

public class FifoQueue<E> extends AbstractQueue<E> {
    private final LinkedList<E> list = new LinkedList<>();

    @Override
    public int size() {
        return list.size();
    }

    @Override
    public boolean offer(E e) {
        return list.add(e); // Adds to the end of the list
    }

    @Override
    public E poll() {
        return list.poll(); // Removes and returns the first element
    }

    @Override
    public E peek() {
        return list.peek(); // Returns the first element without removing it
    }

    @Override
    public Iterator<E> iterator() {
        return list.iterator(); // Returns an iterator for the list
    }
}
