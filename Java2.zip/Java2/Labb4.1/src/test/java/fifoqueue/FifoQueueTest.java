package fifoqueue;

import org.junit.jupiter.api.Test;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

class FifoQueueTest {

    @Test
    void sizeOfEmptyQueueIsZero() {
        FifoQueue<String> queue = new FifoQueue<>();
        assertEquals(0, queue.size());
    }

    @Test
    void offerReturnsTrue() {
        FifoQueue<String> queue = new FifoQueue<>();
        assertTrue(queue.offer("Element"));
    }

    @Test
    void offerIncreasesSize() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("Element");
        assertEquals(1, queue.size());
    }

    @Test
    void peekDoesNotChangeSize() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("Element");
        queue.peek();
        assertEquals(1, queue.size());
    }

    @Test
    void peekOnEmptyQueueReturnsNull() {
        FifoQueue<String> queue = new FifoQueue<>();
        assertNull(queue.peek());
    }

    @Test
    void peekReturnsFirstElement() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("First");
        queue.offer("Second");
        assertEquals("First", queue.peek());
    }

    @Test
    void pollOnEmptyQueueReturnsNull() {
        FifoQueue<String> queue = new FifoQueue<>();
        assertNull(queue.poll());
    }

    @Test
    void pollReturnsFirstElement() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("First");
        queue.offer("Second");
        assertEquals("First", queue.poll());
    }

    @Test
    void pollRemovesFirstElement() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("First");
        queue.offer("Second");
        queue.poll();
        assertEquals("Second", queue.peek());
    }

    @Test
    void iteratorHasNextForNonEmptyQueue() {
        FifoQueue<String> queue = new FifoQueue<>();
        queue.offer("Element");
        Iterator<String> iterator = queue.iterator();
        assertTrue(iterator.hasNext());
    }
}
