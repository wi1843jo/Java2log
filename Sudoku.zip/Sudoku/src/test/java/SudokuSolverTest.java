// src/test/java/SudokuSolverTest.java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SudokuSolverTest {

    @Test
    void testSolveEmptySudoku() {
        SudokuSolver solver = new SudokuSolverImpl();
        assertTrue(solver.solve(), "Löser tom grid");
        assertTrue(solver.isAllValid(), "Körbar");
    }

    @Test
    void testSolveGivenSudoku() {
        SudokuSolver solver = new SudokuSolverImpl();
        int[][] puzzle = {
                {0, 0, 8, 0, 0, 9, 0, 6, 2},
                {0, 0, 0, 0, 0, 0, 0, 0, 5},
                {1, 0, 2, 5, 0, 0, 0, 0, 0},
                {0, 0, 0, 2, 1, 0, 0, 9, 0},
                {0, 5, 0, 0, 0, 0, 6, 0, 0},
                {6, 0, 0, 0, 0, 0, 0, 2, 8},
                {4, 1, 0, 6, 0, 8, 0, 0, 0},
                {8, 6, 0, 0, 3, 0, 1, 0, 0},
                {0, 0, 0, 0, 0, 0, 4, 0, 0}
        };
        solver.setGrid(puzzle);
        assertTrue(solver.solve(), "Ska lösa sudokun");
        assertTrue(solver.isAllValid(), "Ska vara valid");
    }

    @Test
    void testUnsolvableSudoku() {
        SudokuSolver solver = new SudokuSolverImpl();
        int[][] unsolvable = {
                {5, 5, 0, 0, 7, 0, 0, 0, 0}, // Duplicate 5 in the same row
                {6, 0, 0, 1, 9, 5, 0, 0, 0},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };
        solver.setGrid(unsolvable);
        assertFalse(solver.solve(), "Går ej att lösa");
    }
/*
    @Test
    void testSetAndGet() {
        SudokuSolver solver = new SudokuSolverImpl();
        solver.set(0, 0, 5);
        assertEquals(5, solver.get(0, 0), "Sätter (0,0) till 5");
        solver.set(0, 0, 0);
        assertEquals(0, solver.get(0, 0), "Sätter (0,0) till 0");
    }

    @Test
    void testClearAndClearAll() {
        SudokuSolver solver = new SudokuSolverImpl();
        solver.set(0, 0, 5);
        solver.clear(0, 0);
        assertEquals(0, solver.get(0, 0), "sätter 0,0 till 5 sen clearas 0,0 så ska nu vara 0");

        solver.set(0, 0, 5);
        solver.set(1, 1, 6);
        solver.clearAll();
        assertEquals(0, solver.get(0, 0), "ska vara 0 för allt clearades");
        assertEquals(0, solver.get(1, 1), "ska vara 0 för allt clearades");
    }

    @Test
    void testIsAllValid() {
        SudokuSolver solver = new SudokuSolverImpl();
        int[][] puzzle = {
                {5, 3, 0, 0, 7, 0, 0, 0, 0},
                {6, 0, 0, 1, 9, 5, 0, 0, 0},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };
        solver.setGrid(puzzle);
        assertTrue(solver.isAllValid(), "The grid should be valid.");
    }

 */
}
