// Implementation of the SudokuSolver interface
public class SudokuSolverImpl implements SudokuSolver {
    // The grid that stores the Sudoku puzzle
    private int[][] grid;

    // Constructor: Initializes the 9x9 Sudoku grid with zeros (empty cells)
    public SudokuSolverImpl() {
        grid = new int[9][9];
    }

    // Main solve method: Starts solving from the top-left cell (0, 0)
    @Override
    public boolean solve() {
        return solve(0, 0);
    }

    // Recursive backtracking method to solve the puzzle
    private boolean solve(int row, int col) {
        // If we've reached the last row, the Sudoku is solved
        if (row == 9) {
            return true;
        }

        // Move to the next row if we reach the end of a column
        if (col == 9) {
            return solve(row + 1, 0);
        }

        // Skip cells that are already filled
        if (grid[row][col] != 0) {
            return solve(row, col + 1);
        }

        // Try placing numbers 1 through 9 in the cell
        for (int num = 1; num <= 9; num++) {
            if (isValid(row, col, num)) {
                grid[row][col] = num; // Temporarily place the number
                if (solve(row, col + 1)) {
                    return true; // Proceed if successful
                }
                grid[row][col] = 0; // Backtrack if unsuccessful
            }
        }

        return false; // No valid numbers work in this cell
    }

    // Set a number in the grid
    @Override
    public void set(int row, int col, int digit) {
        validateIndex(row, col);
        validateDigit(digit);
        grid[row][col] = digit;
    }

    // Get the number from the grid
    @Override
    public int get(int row, int col) {
        validateIndex(row, col);
        return grid[row][col];
    }

    // Clear a specific cell
    @Override
    public void clear(int row, int col) {
        validateIndex(row, col);
        grid[row][col] = 0;
    }

    // Clear the entire grid
    @Override
    public void clearAll() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                grid[i][j] = 0;
            }
        }
    }

    // Validate if a number is valid in the specified cell
    @Override
    public boolean isValid(int row, int col, int num) {
        if (num < 1 || num > 9) {
            return false;
        }

        // Check row
        for (int c = 0; c < 9; c++) {
            if (c != col && grid[row][c] == num) {
                return false;
            }
        }

        // Check column
        for (int r = 0; r < 9; r++) {
            if (r != row && grid[r][col] == num) {
                return false;
            }
        }

        // Check 3x3 sub-grid
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;
        for (int r = startRow; r < startRow + 3; r++) {
            for (int c = startCol; c < startCol + 3; c++) {
                if ((r != row || c != col) && grid[r][c] == num) {
                    return false;
                }
            }
        }

        return true;
    }

    // Validate if all filled cells are valid
    @Override
    public boolean isAllValid() {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                int num = grid[row][col];
                if (num != 0 && !isValid(row, col, num)) {
                    return false;
                }
            }
        }
        return true;
    }

    // Set the entire grid from an input matrix
    @Override
    public void setGrid(int[][] m) {
        if (m == null || m.length != 9 || m[0].length != 9) {
            throw new IllegalArgumentException("Grid must be a 9x9 matrix.");
        }
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                int num = m[i][j];
                if (num < 0 || num > 9) {
                    throw new IllegalArgumentException("Grid values must be between 0 and 9.");
                }
                grid[i][j] = num;
            }
        }
    }

    // Return the entire grid as a matrix
    @Override
    public int[][] getGrid() {
        return grid;
    }

    // Helper methods to validate indices and digits
    private void validateIndex(int row, int col) {
        if (row < 0 || row >= 9 || col < 0 || col >= 9) {
            throw new IndexOutOfBoundsException("Row or column out of bounds");
        }
    }

    private void validateDigit(int digit) {
        if (digit < 0 || digit > 9) {
            throw new IllegalArgumentException("Digit must be between 0 and 9");
        }
    }
}
