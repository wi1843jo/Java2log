// Sudoku GUI: Provides a graphical user interface for the SudokuSolverImpl.
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SudokuGUI {
    private JFrame frame;
    private JPanel panel;
    private JTextField[][] cells;
    private SudokuSolverImpl solver;

    public SudokuGUI() {
        solver = new SudokuSolverImpl();
        frame = new JFrame("Sudoku Solver");
        panel = new JPanel();
        panel.setLayout(new GridLayout(9, 9));
        cells = new JTextField[9][9];

        Color color1 = new Color(255, 0, 234);
        Color color2 = Color.WHITE;

        // Create a 9x9 grid of text fields
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                cells[row][col] = new JTextField();
                cells[row][col].setHorizontalAlignment(JTextField.CENTER);
                cells[row][col].setFont(new Font("Arial", Font.PLAIN, 20));
                panel.add(cells[row][col]);

                boolean color = ((row / 3) + (col / 3)) % 2 == 0;
                cells[row][col].setBackground(color ? color1 : color2);

                panel.add(cells[row][col]);
            }
        }

        // Solve button
        JButton solveButton = new JButton("Solve");
        solveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSolve();
            }
        });

        // Clear button
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleClear();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(solveButton);
        buttonPanel.add(clearButton);

        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 450);
        frame.setVisible(true);
    }

    private void handleSolve() {
        try {
            for (int row = 0; row < 9; row++) {
                for (int col = 0; col < 9; col++) {
                    String text = cells[row][col].getText();
                    if (!text.isEmpty()) {
                        solver.set(row, col, Integer.parseInt(text));
                    }
                }
            }
            if (!solver.isAllValid()) {
                showMessage("Invalid Sudoku grid!", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (solver.solve()) {
                updateGrid();
            } else {
                showMessage("This Sudoku puzzle is unsolvable.", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            showMessage("Input error: " + ex.getMessage(), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleClear() {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                cells[row][col].setText("");
            }
        }
        solver.clearAll();
    }

    private void updateGrid() {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                cells[row][col].setText(String.valueOf(solver.get(row, col)));
            }
        }
    }

    private void showMessage(String message, int type) {
        JOptionPane.showMessageDialog(frame, message, "Sudoku Solver", type);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SudokuGUI::new);
    }
}